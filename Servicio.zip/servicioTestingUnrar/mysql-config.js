const config = {
    host: 'meta-db.coikvaadq6ut.us-east-1.rds.amazonaws.com',
    user : 'admin',
    password : 'rootroot',
    database : 'ventas'
};

module.exports = config;