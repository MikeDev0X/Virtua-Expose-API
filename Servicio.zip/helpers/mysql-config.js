const config = {
    host: 'db-meta.coikvaadq6ut.us-east-1.rds.amazonaws.com',
    user : 'admin',
    password : 'rootroot',
    database : 'metaverse'
};

module.exports = config;